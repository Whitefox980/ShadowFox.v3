The XmpInformation Class
-------------------------

.. autoclass:: pypdf.xmp.XmpInformation
    :members:
    :undoc-members:
    :show-inheritance:
