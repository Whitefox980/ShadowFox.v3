The annotations module
----------------------

.. automodule:: pypdf.annotations
    :members:
    :undoc-members:
    :show-inheritance:
