Errors
------

.. automodule:: pypdf.errors
    :members:
    :undoc-members:
    :show-inheritance:
